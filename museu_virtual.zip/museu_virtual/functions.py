from os import system
from time import sleep
from datetime import datetime

def bubble_sort(list):
    qtd = len(list)
    for i in range(qtd):
        for indice in range(0, qtd-i-1):
            if list[indice] > list[indice+1]:
                list[indice], list[indice+1] = list[indice+1], list[indice]
    return list

def login(users):
    while True:
        print('='*20)
        print('Museu Digital')
        print('='*20)

        login = input('Login: ')
        password = input('Senha: ')

        i = 0
        for user in users:
            if login == user["login"]:
                if password == user["password"]:
                    return user["acess_type"]
                else:
                    print('Senha incorreta!')
                    sleep(1.2)
                    system('cls')
                    continue
            else:
                i += 1
                if i >= len(users):
                    print('Usuário não encontrado!')
                    sleep(1.2)
                    system('cls')
                    continue

def explore(arts, rented_arts):
    while True:
        system('cls')
        print('Obras do museu: \n')

        titles = []
        for obra in arts:
            titles.append(obra["title"])
        titles_ordened = bubble_sort(titles)
        for i, name in enumerate(titles_ordened):
            print(f'{i+1} - {name}' )

        selection = input('\nSelecione uma obra: ')
        try:
            int(selection)
            if int(selection) > len(titles_ordened):
                print('Selecione uma opção válida.')
                sleep(1.5)
                system('cls')
                continue

        except ValueError:
            print('Você digitou um caractere inválido')
            sleep(1.5)
            system('cls')
            continue
        
        obra_escolhida = titles_ordened[int(selection)-1]
        
        for obra in arts:
            if obra_escolhida == obra["title"]:
                while True:
                    system('cls')
                    print('Obra selecionada: \n')
                    print(f'Título: {obra["title"]}')
                    print(f'Autor(a): {obra["author"]}')
                    print(f'Data de lançamento: {obra["date"]}')
                    print(f'Estilo: {obra["style"]}')
                    print(f'Técnica usada: {obra["tecnica"]}')
                    print(f'\nDescrição: {obra["description"]}')
                    alugar = input('\nDeseja alugar?[S/N]: ')

                    if alugar.lower() == 's' or alugar.lower == 'sim':
                        rented_arts.append(obra_escolhida)
                        log_registros(obra_escolhida)
                    elif alugar.lower() == 'n' or alugar.lower == 'nao':
                        break

def log_registros(name):
    with open('log', 'w') as registros_de_alugueis:
        registros_de_alugueis.write(f"A obra {name} foi alugada na data {datetime.now()} pelo usuario")